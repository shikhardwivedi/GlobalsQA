package StepDef;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import GlobalElements.elementsGlobal;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class StepDefinition {
	WebDriver driver;
	elementsGlobal eg;
	

@Given("I open the browser")
public void i_open_the_browser() {
	WebDriverManager.chromedriver().setup();
	driver=new ChromeDriver();
	eg=new elementsGlobal(driver);
  
}
@When("I go to the URL {string}")
public void i_go_to_the_url(String string) throws InterruptedException {
	driver.get(string);
	driver.manage().window().maximize();
  Thread.sleep(2000);
    
}
@When("I Mouse hover the first image and Print the tooltip")
public void i_mouse_hover_the_first_image_and_print_the_tooltip() throws Exception {
	driver.switchTo().frame(0);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,300)", "");
	Actions action = new Actions(driver);
	action.moveToElement(eg.Image1).build().perform();
	System.out.println("toolstip of the Image1 = " + eg.Image1.getAttribute("alt"));
	Thread.sleep(1000);
   
}
@When("I Mouse hover the second image and Print the tooltip")
public void i_mouse_hover_the_second_image_and_print_the_tooltip() throws InterruptedException {
    
    Actions action = new Actions(driver);
	action.moveToElement(eg.Image2).build().perform();
	System.out.println("toolstips of Image2 = " + eg.Image2.getAttribute("alt"));
	driver.switchTo().defaultContent();
	Thread.sleep(1000);
}
@Then("I will click on the Video Based button")
public void i_will_click_on_the_video_based_button() throws InterruptedException {
	driver.switchTo().defaultContent();
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,-250)", "");
	Actions action=new Actions(driver);
	action.moveToElement(eg.Videobtn).click().build().perform();
  
  Thread.sleep(3000);
    
}
@Then("I mouse hover the LIKE button and Print the tooltip")
public void i_mouse_hover_the_like_button_and_print_the_tooltip() throws InterruptedException {
	driver.switchTo().defaultContent();
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,350)", "");
	driver.switchTo().frame(1);
	Actions action = new Actions(driver);
	action.moveToElement(eg.Like).build().perform();
	System.out.println("toolstips of Like = " + eg.Like.getAttribute("title"));
	Thread.sleep(3000);

   
}
@Then("I mouse over the ADD TO button and Print the tooltip")
public void i_mouse_over_the_add_to_button_and_print_the_tooltip() throws InterruptedException {
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,300)", "");
	Actions action = new Actions(driver);
	action.moveToElement(eg.addTo).build().perform();
	System.out.println("toolstips of Add To Button = " + eg.addTo.getAttribute("title"));
	Thread.sleep(3000);
   
   
}
@Then("I mouse over the SHARE button and Print the tooltip")
public void i_mouse_over_the_share_button_and_print_the_tooltip() throws InterruptedException {
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,300)", "");
	Actions action = new Actions(driver);
	action.moveToElement(eg.share).build().perform();
	System.out.println("toolstips of Share Button = " + eg.share.getAttribute("title"));
	driver.switchTo().defaultContent();
	Thread.sleep(3000);
   
}
@Then("I click on the Form Base button")
public void i_click_on_the_form_base_button() throws Exception {
	driver.switchTo().defaultContent();
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,-300)", "");
	Actions action=new Actions(driver);
	action.moveToElement(eg.formbtn).click().build().perform();
	Thread.sleep(2000);
    
    
}
@Then("I mouse hover the first name and Print the tooltip")
public void i_mouse_hover_the_first_name_and_print_the_tooltip() throws InterruptedException {
	driver.switchTo().defaultContent();
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,100)", "");
	driver.switchTo().frame(2);
	Actions action = new Actions(driver);
	action.moveToElement(eg.firstname).build().perform();
	System.out.println("toolstips of First Name = " + eg.firstname.getAttribute("title=\"Please provide your firstname.\""));
	Thread.sleep(3000);
   
    
}
@Then("I Mouse hover the Last Name and Print the tooltip")
public void i_mouse_hover_the_last_name_and_print_the_tooltip() throws InterruptedException {
	Actions action = new Actions(driver);
	action.moveToElement(eg.lastname).build().perform();
	System.out.println("toolstips of Last Name = " + eg.lastname.getAttribute("title"));
	Thread.sleep(3000);
    
   
}
@Then("I mouse hover the Address and Print the tooltip")
public void i_mouse_hover_the_address_and_print_the_tooltip() throws InterruptedException {
	Actions action = new Actions(driver);
	action.moveToElement(eg.address).build().perform();
	System.out.println("toolstips of Address = " + eg.address.getAttribute("title"));
	Thread.sleep(3000);
}
@Then("I close the browser")
public void i_close_the_browser() {
    driver.close();
}
}







































