package GlobalElements;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class elementsGlobal {
	
	WebDriver ldriver;
 	public elementsGlobal(WebDriver rdriver) {
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);

}
	@FindBy(id="Image Based")
	public WebElement imagebtn;
	
	@FindBy(xpath="//img[@alt=\"St. Stephen's Cathedral\"]")
	public WebElement Image1;
	
	@FindBy(xpath="//img[@alt='Tower Bridge']")
	public WebElement Image2;
	
	@FindBy(xpath="//div[@id='post-2679']//div[@class='twelve columns']//div//ul//li[@id='Video Based']")
	public WebElement Videobtn;
	
	@FindBy(xpath="//button[normalize-space()='Like']")
	public WebElement Like;
	
	@FindBy(xpath="//div[@class='set ui-controlgroup ui-controlgroup-horizontal ui-helper-clearfix']/button[@class='ui-widget ui-controlgroup-item ui-button ui-corner-left']")
	public WebElement addTo;
	
	@FindBy(xpath="//button[@class='ui-button ui-corner-all ui-widget']")
	public WebElement share;
	
	@FindBy(xpath="//li[@id='Forms Based']")
	public WebElement formbtn;
	
	@FindBy(xpath="//input[@id='firstname']")
	public WebElement firstname;
	
	@FindBy(xpath="//input[@id='lastname']")
	public WebElement lastname;
	
	@FindBy(xpath="//input[@id='address']")
	public WebElement address;
	
}

